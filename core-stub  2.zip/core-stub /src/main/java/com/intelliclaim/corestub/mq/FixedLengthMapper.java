package com.intelliclaim.corestub.mq;

import com.intelliclaim.corestub.dto.ClaimRequestDTO;
import com.intelliclaim.corestub.model.Claim;
import com.intelliclaim.corestub.model.Policy;

import java.util.List;
import java.util.stream.Collectors;

/**
 * FixedLengthMapper
 *
 * Parser for incoming fixed-length requests and builders for various fixed-length responses.
 * Keeps a clear, defensive approach for substring boundaries and numeric parsing.
 */
public class FixedLengthMapper {

    // Incoming request fixed-length spec
    private static final int MSG_TYPE_LEN = 10;
    private static final int POLICY_NUM_LEN = 20;
    private static final int HOLDER_NAME_LEN = 40;
    private static final int AMOUNT_LEN = 10;

    private static final int OFFSET_MSG_TYPE = 0;
    private static final int OFFSET_POLICY_NUM = OFFSET_MSG_TYPE + MSG_TYPE_LEN; // 10
    private static final int OFFSET_HOLDER_NAME = OFFSET_POLICY_NUM + POLICY_NUM_LEN; // 30
    private static final int OFFSET_AMOUNT = OFFSET_HOLDER_NAME + HOLDER_NAME_LEN; // 70

    // Claim response fixed-length fields (for sending claim records to response queue)
    private static final int CLAIM_MSG_TYPE_LEN = 10;
    private static final int CLAIM_ID_LEN = 20;
    private static final int CLAIM_POLICY_NUM_LEN = 20;
    private static final int CLAIM_HOLDER_NAME_LEN = 40;
    private static final int CLAIM_AMOUNT_LEN = 10;
    private static final int CLAIM_STATUS_LEN = 10;
    // total claim message length = 10 + 20 + 20 + 40 + 10 + 10 = 110

    // ---------------- Parser: fixed-length -> ClaimRequestDTO ----------------
    public static ClaimRequestDTO parseFixedToClaimRequest(String raw) {
        ClaimRequestDTO dto = new ClaimRequestDTO();
        if (raw == null) return dto;

        String r = raw;

        // policyNumber
        String policyNumber = "";
        if (r.length() >= OFFSET_POLICY_NUM + 1) {
            int end = Math.min(r.length(), OFFSET_POLICY_NUM + POLICY_NUM_LEN);
            policyNumber = safeSubstring(r, OFFSET_POLICY_NUM, end).trim();
        }

        // claimantName
        String claimantName = "";
        if (r.length() >= OFFSET_HOLDER_NAME + 1) {
            int end = Math.min(r.length(), OFFSET_HOLDER_NAME + HOLDER_NAME_LEN);
            claimantName = safeSubstring(r, OFFSET_HOLDER_NAME, end).trim();
        }

        // claimAmount (right aligned)
        Double claimAmount = null;
        if (r.length() >= OFFSET_AMOUNT + 1) {
            int end = Math.min(r.length(), OFFSET_AMOUNT + AMOUNT_LEN);
            String amtStr = safeSubstring(r, OFFSET_AMOUNT, end).trim();

            if (!amtStr.isEmpty()) {
                // remove any characters except digits, dot and minus sign (defensive)
                String cleaned = amtStr.replaceAll("[^0-9.\\-]", "");
                try {
                    claimAmount = Double.valueOf(cleaned);
                } catch (NumberFormatException e) {
                    // fallback: try replacing commas
                    try {
                        claimAmount = Double.valueOf(cleaned.replaceAll(",", ""));
                    } catch (Exception ex) {
                        claimAmount = null;
                    }
                }
            }
        }

        dto.setPolicyNumber(policyNumber);
        dto.setClaimantName(claimantName);
        dto.setClaimAmount(claimAmount);

        return dto;
    }

    // ---------------- Existing helpers / request builders (kept) ----------------

    /**
     * Build a fixed-length request from a policy number (useful for tests).
     */
    public static String buildFixedRequest(String policyNumber) {
        return padRight("REQ", MSG_TYPE_LEN)
                + padRight(policyNumber == null ? "" : policyNumber, POLICY_NUM_LEN)
                + padRight("", HOLDER_NAME_LEN)
                + padLeft("0.00", AMOUNT_LEN);
    }

    /**
     * Build the fixed-length response from a Policy model.
     * Format: RESP (10) | policyNumber (20) | holderName (40) | sumInsured (10 right aligned, 2 decimals)
     */
    public static String buildFixedResponse(Policy p) {
        StringBuilder sb = new StringBuilder();
        sb.append(padRight("RESP", MSG_TYPE_LEN));
        sb.append(padRight(nullSafe(p.getPolicyNumber()), POLICY_NUM_LEN));
        sb.append(padRight(nullSafe(p.getPolicyHolderName()), HOLDER_NAME_LEN));
        double amount = p.getSumInsured() == null ? 0.0 : p.getSumInsured();
        sb.append(padLeft(String.format("%.2f", amount), AMOUNT_LEN));
        return sb.toString();
    }

    /**
     * Build a NOT_FOUND fixed-length response given a requested policyNumber.
     */
    public static String buildNotFoundResponse(String policyNumber) {
        StringBuilder sb = new StringBuilder();
        sb.append(padRight("RESP", MSG_TYPE_LEN));
        sb.append(padRight(policyNumber == null ? "" : policyNumber, POLICY_NUM_LEN));
        sb.append(padRight("NOT_FOUND", HOLDER_NAME_LEN));
        sb.append(padLeft("0.00", AMOUNT_LEN));
        return sb.toString();
    }

    /**
     * Build an UNKNOWN response for missing/invalid requests.
     */
    public static String buildUnknownResponse() {
        StringBuilder sb = new StringBuilder();
        sb.append(padRight("RESP", MSG_TYPE_LEN));
        sb.append(padRight("UNKNOWN", POLICY_NUM_LEN));
        sb.append(padRight("", HOLDER_NAME_LEN));
        sb.append(padLeft("0.00", AMOUNT_LEN));
        return sb.toString();
    }

    // ---------------- NEW: claim -> fixed-length message builder ----------------

    /**
     * Build a fixed-length message representing a Claim to be sent on response queue.
     * Format:
     *  messageType (10) | claimId (20) | policyNumber (20) | claimantName (40) | claimAmount (10 right aligned) | status (10)
     */
    public static String buildFixedClaimMessage(Claim c) {
        StringBuilder sb = new StringBuilder();
        sb.append(padRight("CLMRESP", CLAIM_MSG_TYPE_LEN));
        sb.append(padRight(nullSafe(c.getClaimId()), CLAIM_ID_LEN));
        sb.append(padRight(nullSafe(c.getPolicyNumber()), CLAIM_POLICY_NUM_LEN));
        sb.append(padRight(nullSafe(c.getClaimantName()), CLAIM_HOLDER_NAME_LEN));
        double amount = c.getClaimAmount() == null ? 0.0 : c.getClaimAmount();
        sb.append(padLeft(String.format("%.2f", amount), CLAIM_AMOUNT_LEN));
        sb.append(padRight(nullSafe(c.getStatus()), CLAIM_STATUS_LEN));
        return sb.toString();
    }

    public static List<String> buildFixedClaimMessages(List<Claim> claims) {
        return claims.stream().map(FixedLengthMapper::buildFixedClaimMessage).collect(Collectors.toList());
    }

    // ---------------- Utility helpers ----------------

    private static String safeSubstring(String s, int startInclusive, int endExclusive) {
        if (s == null || startInclusive >= s.length()) return "";
        int safeEnd = Math.min(endExclusive, s.length());
        if (startInclusive < 0) startInclusive = 0;
        if (safeEnd <= startInclusive) return "";
        return s.substring(startInclusive, safeEnd);
    }

    public static String padRight(String s, int size) {
        if (s == null) s = "";
        if (s.length() > size) return s.substring(0, size);
        return String.format("%-" + size + "s", s);
    }

    public static String padLeft(String s, int size) {
        if (s == null) s = "";
        if (s.length() > size) return s.substring(0, size);
        return String.format("%" + size + "s", s);
    }

    private static String nullSafe(String s) { return s == null ? "" : s; }

    // If you keep using buildFixedResponse/buildNotFoundResponse elsewhere, those methods above must be present.
}
