package com.intelliclaim.corestub.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import java.time.Instant;

@Document(collection = "audit.logs")
public class AuditLog {
    @Id
    private String id;
    private String requestRaw;
    private String responseRaw;
    private Instant timestamp;

    public AuditLog() {
        this.timestamp = Instant.now();
    }

    public String getId() { return id; }
    public void setId(String id) { this.id = id; }

    public String getRequestRaw() { return requestRaw; }
    public void setRequestRaw(String requestRaw) { this.requestRaw = requestRaw; }

    public String getResponseRaw() { return responseRaw; }
    public void setResponseRaw(String responseRaw) { this.responseRaw = responseRaw; }

    public Instant getTimestamp() { return timestamp; }
    public void setTimestamp(Instant timestamp) { this.timestamp = timestamp; }
}
