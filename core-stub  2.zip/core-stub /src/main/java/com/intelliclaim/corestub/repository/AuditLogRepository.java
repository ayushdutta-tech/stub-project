package com.intelliclaim.corestub.repository;

import com.intelliclaim.corestub.model.AuditLog;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface AuditLogRepository extends MongoRepository<AuditLog, String> {
}
