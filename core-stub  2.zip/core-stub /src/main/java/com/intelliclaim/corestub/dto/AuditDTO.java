package com.intelliclaim.corestub.dto;

import java.time.Instant;

public class AuditDTO {
    private String requestRaw;
    private String responseRaw;
    private Instant timestamp;

    public AuditDTO() {}

    public AuditDTO(String requestRaw, String responseRaw, Instant timestamp) {
        this.requestRaw = requestRaw;
        this.responseRaw = responseRaw;
        this.timestamp = timestamp;
    }

    public String getRequestRaw() { return requestRaw; }
    public void setRequestRaw(String requestRaw) { this.requestRaw = requestRaw; }

    public String getResponseRaw() { return responseRaw; }
    public void setResponseRaw(String responseRaw) { this.responseRaw = responseRaw; }

    public Instant getTimestamp() { return timestamp; }
    public void setTimestamp(Instant timestamp) { this.timestamp = timestamp; }
}
