package com.intelliclaim.corestub.dto;

public class PolicyResponseDTO {
    private String policyNumber;
    private String policyHolderName;
    private String productCode;
    private Double sumInsured;
    private String statusMessage;

    public PolicyResponseDTO() {}

    public PolicyResponseDTO(String policyNumber, String policyHolderName, String productCode, Double sumInsured, String statusMessage) {
        this.policyNumber = policyNumber;
        this.policyHolderName = policyHolderName;
        this.productCode = productCode;
        this.sumInsured = sumInsured;
        this.statusMessage = statusMessage;
    }

    public String getPolicyNumber() { return policyNumber; }
    public void setPolicyNumber(String policyNumber) { this.policyNumber = policyNumber; }

    public String getPolicyHolderName() { return policyHolderName; }
    public void setPolicyHolderName(String policyHolderName) { this.policyHolderName = policyHolderName; }

    public String getProductCode() { return productCode; }
    public void setProductCode(String productCode) { this.productCode = productCode; }

    public Double getSumInsured() { return sumInsured; }
    public void setSumInsured(Double sumInsured) { this.sumInsured = sumInsured; }

    public String getStatusMessage() { return statusMessage; }
    public void setStatusMessage(String statusMessage) { this.statusMessage = statusMessage; }
}
