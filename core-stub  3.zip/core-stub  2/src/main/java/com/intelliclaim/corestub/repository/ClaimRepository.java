package com.intelliclaim.corestub.repository;

import com.intelliclaim.corestub.model.Claim;
import org.springframework.data.mongodb.repository.MongoRepository;

import java.util.Optional;

public interface ClaimRepository extends MongoRepository<Claim, String> {
    Optional<Claim> findByRequestHash(String requestHash);
    Optional<Claim> findByClaimId(String claimId);
}
