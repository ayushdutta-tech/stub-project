package com.intelliclaim.corestub.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import java.time.LocalDateTime;

@Document(collection = "policies")
public class Policy {

    @Id
    private String id;

    // --- Mandatory core fields ---
    private String policyNumber;
    private String policyHolderName;
    private String productCode;
    private Double sumInsured;
    private String effectiveDate;

    // --- Extended metadata fields ---
    private String expiryDate;
    private String policyType;
    private Double premiumAmount;
    private String status = "PENDING"; // default value
    private String fraudStatus; // Accept / Reject
    private LocalDateTime createdDate = LocalDateTime.now();
    private LocalDateTime updatedDate = LocalDateTime.now();

    // --- Additional fields ---
    private String agentName; // Policy agent or broker
    private String branchCode; // Issuing branch or office
    private String lastClaimDate;
    private String MandatoryDocuments;

    public Policy() {}

    // --- Getters and Setters ---

    public String getId() { return id; }
    public void setId(String id) { this.id = id; }

    public String getPolicyNumber() { return policyNumber; }
    public void setPolicyNumber(String policyNumber) { this.policyNumber = policyNumber; }

    public String getPolicyHolderName() { return policyHolderName; }
    public void setPolicyHolderName(String policyHolderName) { this.policyHolderName = policyHolderName; }

    public String getProductCode() { return productCode; }
    public void setProductCode(String productCode) { this.productCode = productCode; }

    public Double getSumInsured() { return sumInsured; }
    public void setSumInsured(Double sumInsured) { this.sumInsured = sumInsured; }

    public String getEffectiveDate() { return effectiveDate; }
    public void setEffectiveDate(String effectiveDate) { this.effectiveDate = effectiveDate; }

    public String getExpiryDate() { return expiryDate; }
    public void setExpiryDate(String expiryDate) { this.expiryDate = expiryDate; }

    public String getPolicyType() { return policyType; }
    public void setPolicyType(String policyType) { this.policyType = policyType; }

    public Double getPremiumAmount() { return premiumAmount; }
    public void setPremiumAmount(Double premiumAmount) { this.premiumAmount = premiumAmount; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    public String getFraudStatus() { return fraudStatus; }
    public void setFraudStatus(String fraudStatus) { this.fraudStatus = fraudStatus; }

    public LocalDateTime getCreatedDate() { return createdDate; }
    public void setCreatedDate(LocalDateTime createdDate) { this.createdDate = createdDate; }

    public LocalDateTime getUpdatedDate() { return updatedDate; }
    public void setUpdatedDate(LocalDateTime updatedDate) { this.updatedDate = updatedDate; }

    public String getAgentName() { return agentName; }
    public void setAgentName(String agentName) { this.agentName = agentName; }

    public String getBranchCode() { return branchCode; }
    public void setBranchCode(String branchCode) { this.branchCode = branchCode; }

    public String getLastClaimDate() { return lastClaimDate; }

    public String getMandatoryDocuments() {
        return MandatoryDocuments;
    }

    public void setMandatoryDocuments(String mandatoryDocuments) {
        MandatoryDocuments = mandatoryDocuments;
    }

    public void setLastClaimDate(String lastClaimDate) { this.lastClaimDate = lastClaimDate; }
}
