package com.intelliclaim.corestub.mq;

import com.intelliclaim.corestub.service.CoreStubService;
import jakarta.jms.Message;
import jakarta.jms.TextMessage;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jms.annotation.JmsListener;
import org.springframework.stereotype.Component;

@Component
public class MqListener {
    private static final Logger log = LoggerFactory.getLogger(MqListener.class);

    private final CoreStubService coreStubService;

    @Value("${app.ibm-mq.request-queue:CORE.REQUEST.QUEUE}")
    private String requestQueue;

    @Value("${app.ibm-mq.response-queue:CORE.RESPONSE.QUEUE}")
    private String responseQueue;

    public MqListener(CoreStubService coreStubService) {
        this.coreStubService = coreStubService;
    }

    // NOTE: destination is read from property; the annotation value here is a constant only to enable the listener bean.
    // We still pass the configured responseQueue into the service so it uses app property.
    @JmsListener(destination = "${app.ibm-mq.request-queue:CORE.REQUEST.QUEUE}", containerFactory = "jmsListenerContainerFactory")
    public void onMessage(Message message) {
        try {
            log.info("[MQ Listener] Enter");
            String payload;
            if (message instanceof TextMessage) {
                payload = ((TextMessage) message).getText();
            } else {
                payload = message.getBody(String.class);
            }
            log.info("[MQ Listener] Received message -> {}", payload);
            coreStubService.handleRawRequest(payload, responseQueue);
        } catch (Exception e) {
            log.error("[MQ Listener] Error processing message", e);
        }
    }
}
