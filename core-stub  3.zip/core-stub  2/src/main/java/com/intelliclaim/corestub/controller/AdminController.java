package com.intelliclaim.corestub.controller;

import com.intelliclaim.corestub.dto.AuditDTO;
import com.intelliclaim.corestub.dto.PolicyResponseDTO;
import com.intelliclaim.corestub.model.AuditLog;
import com.intelliclaim.corestub.model.Policy;
import com.intelliclaim.corestub.repository.AuditLogRepository;
import com.intelliclaim.corestub.repository.PolicyRepository;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/admin")
public class AdminController {

    private final PolicyRepository policyRepository;
    private final AuditLogRepository auditLogRepository;

    public AdminController(PolicyRepository policyRepository, AuditLogRepository auditLogRepository) {
        this.policyRepository = policyRepository;
        this.auditLogRepository = auditLogRepository;
    }

    @GetMapping("/policies")
    public List<PolicyResponseDTO> getAllPolicies() {
        return policyRepository.findAll().stream()
                .map(p -> new PolicyResponseDTO(p.getPolicyNumber(), p.getPolicyHolderName(), p.getProductCode(), p.getSumInsured(), "OK"))
                .collect(Collectors.toList());
    }

    @PostMapping("/policies")
    public ResponseEntity<PolicyResponseDTO> createPolicy(@RequestBody Policy policy) {
        Policy saved = policyRepository.save(policy);
        PolicyResponseDTO dto = new PolicyResponseDTO(saved.getPolicyNumber(), saved.getPolicyHolderName(), saved.getProductCode(), saved.getSumInsured(), "CREATED");
        return ResponseEntity.ok(dto);
    }

    @GetMapping("/audits")
    public List<AuditDTO> getAudits() {
        List<AuditLog> logs = auditLogRepository.findAll();
        return logs.stream().map(l -> new AuditDTO(l.getRequestRaw(), l.getResponseRaw(), l.getTimestamp())).collect(Collectors.toList());
    }
}
