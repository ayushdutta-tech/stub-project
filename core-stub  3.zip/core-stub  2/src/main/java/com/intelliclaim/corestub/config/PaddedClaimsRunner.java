package com.intelliclaim.corestub.config;

import com.intelliclaim.corestub.model.Claim;
import com.intelliclaim.corestub.mq.FixedLengthMapper;
import com.intelliclaim.corestub.repository.ClaimRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Component;

import java.util.List;

/**
 * Runner that prints padded fixed-length claim messages to logs so you can verify formatting
 * even when MQ is not available. Enabled only when 'padded-runner' profile is active.
 */
@Component
@Profile("padded-runner")
public class PaddedClaimsRunner implements ApplicationRunner {

    private static final Logger log = LoggerFactory.getLogger(PaddedClaimsRunner.class);

    private final ClaimRepository claimRepository;

    public PaddedClaimsRunner(ClaimRepository claimRepository) {
        this.claimRepository = claimRepository;
    }

    @Override
    public void run(ApplicationArguments args) {
        log.info("[PaddedClaimsRunner] Starting padded claims inspection run");

        List<Claim> claims;
        try {
            claims = claimRepository.findAll();
        } catch (Exception e) {
            log.error("[PaddedClaimsRunner] Failed to read claims from repository", e);
            return;
        }

        if (claims == null || claims.isEmpty()) {
            log.info("[PaddedClaimsRunner] No claims found to inspect");
            return;
        }

        int idx = 0;
        for (Claim c : claims) {
            idx++;
            try {
                String padded = FixedLengthMapper.buildFixedClaimMessage(c);
                // Log metadata + visible markers so it's easy to copy/paste and verify positions
                log.info("[PaddedClaimsRunner] Claim[{}] id={} paddedLen={} ->", idx, c.getClaimId(), padded == null ? 0 : padded.length());
                // show a hex-like printable version for whitespace visibility (replace spaces with ·)
                String vis = padded.replace(' ', '·');
                log.info("[PaddedClaimsRunner] >>> {} <<<", vis);
                // Also log raw padded (actual payload) so you can copy/send to MQ if needed
                log.info("[PaddedClaimsRunner] RAW:{}", padded);
            } catch (Exception ex) {
                log.error("[PaddedClaimsRunner] Failed to build padded message for claimId=" + c.getClaimId(), ex);
            }
        }

        log.info("[PaddedClaimsRunner] Finished padded claims inspection run (count={})", claims.size());
    }
}
