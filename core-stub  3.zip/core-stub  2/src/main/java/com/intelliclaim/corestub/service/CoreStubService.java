package com.intelliclaim.corestub.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.intelliclaim.corestub.dto.ClaimRequestDTO;
import com.intelliclaim.corestub.model.AuditLog;
import com.intelliclaim.corestub.model.Claim;
import com.intelliclaim.corestub.model.Policy;
import com.intelliclaim.corestub.mq.FixedLengthMapper;
import com.intelliclaim.corestub.repository.AuditLogRepository;
import com.intelliclaim.corestub.repository.ClaimRepository;
import com.intelliclaim.corestub.repository.PolicyRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.stereotype.Service;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import java.util.stream.Collectors;

@Service
public class CoreStubService {

    private static final Logger log = LoggerFactory.getLogger(CoreStubService.class);

    private final PolicyRepository policyRepository;
    private final AuditLogRepository auditLogRepository;
    private final ClaimRepository claimRepository;
    private final JmsTemplate jmsTemplate;
    private final ObjectMapper objectMapper = new ObjectMapper();

    @Value("${app.ibm-mq.response-queue:CORE.RESPONSE.QUEUE}")
    private String configuredResponseQueue;

    public CoreStubService(PolicyRepository policyRepository,
                           AuditLogRepository auditLogRepository,
                           ClaimRepository claimRepository,
                           JmsTemplate jmsTemplate) {
        this.policyRepository = policyRepository;
        this.auditLogRepository = auditLogRepository;
        this.claimRepository = claimRepository;
        this.jmsTemplate = jmsTemplate;
    }

    /**
     * Handle raw incoming request (JSON or fixed-length).
     * Save a Claim (if new) with status=PENDING + generated claimId.
     * Then publish claims as fixed-length messages to response queue.
     * Also preserve original policy lookup/response behaviour (sends single policy response).
     *
     * @param rawRequest incoming raw payload
     * @param responseQueue explicit response queue override (if null uses configuredResponseQueue)
     */
    public void handleRawRequest(String rawRequest, String responseQueue) {
        log.info("[CoreStubService] Received raw MQ message = {}", rawRequest);
        if (rawRequest == null) rawRequest = "";

        ClaimRequestDTO requestDto;
        String requestJson;

        // STEP 1 — Parse/normalize
        try {
            String trimmed = rawRequest.trim();
            if (trimmed.startsWith("{")) {
                requestDto = objectMapper.readValue(trimmed, ClaimRequestDTO.class);
            } else {
                requestDto = FixedLengthMapper.parseFixedToClaimRequest(rawRequest);
            }
            requestJson = objectMapper.writeValueAsString(requestDto);
        } catch (Exception e) {
            log.error("[CoreStubService] Failed to parse incoming message, storing as UNKNOWN DTO", e);
            requestDto = new ClaimRequestDTO();
            requestJson = "{}";
        }

        // dedupe using request hash
        final String requestHash = sha256Hex(requestJson);

        // STEP 2 — Save claim if not duplicate
        try {
            Optional<Claim> maybe = claimRepository.findByRequestHash(requestHash);
            if (maybe.isPresent()) {
                log.info("[CoreStubService] Duplicate request (hash={}) — existing claimId={}", requestHash, maybe.get().getClaimId());
            } else {
                Claim claim = new Claim();
                // generate short unique claim id
                String shortUuid = UUID.randomUUID().toString().replaceAll("-", "").substring(0, 8).toUpperCase();
                claim.setClaimId("CLM-" + shortUuid);
                claim.setPolicyNumber(requestDto.getPolicyNumber());
                claim.setClaimantName(requestDto.getClaimantName());
                claim.setClaimAmount(requestDto.getClaimAmount());
                claim.setRequestHash(requestHash);
                claim.setStatus("PENDING");
                claim.setCreatedDate(LocalDateTime.now());

                claimRepository.save(claim);
                log.info("[CoreStubService] Saved incoming claim to Mongo (claimId={}, policyNumber={})",
                        claim.getClaimId(), claim.getPolicyNumber());
            }
        } catch (Exception e) {
            log.error("[CoreStubService] Error while saving claim (continuing):", e);
        }

        // STEP 3a — publish claims specifically for this policy number (if present)
        String policyNumber = requestDto.getPolicyNumber();
        try {
            if (policyNumber != null && !policyNumber.isBlank()) {
                publishClaimsByPolicyToResponseQueueInternal(policyNumber, responseQueue);
            } else {
                log.debug("[CoreStubService] No policyNumber provided in request; skipping per-policy publish.");
            }
        } catch (Exception e) {
            log.error("[CoreStubService] Failed to publish per-policy claims to response queue", e);
        }

        // STEP 3b — publish all claims as fixed-length messages to response queue (existing behaviour)
        try {
            publishAllClaimsAsFixedToResponseQueueInternal(responseQueue);
        } catch (Exception e) {
            log.error("[CoreStubService] Failed to publish claims to response queue", e);
        }

        // STEP 4 — preserve original policy lookup/response behaviour (sends single policy response)
        String responseRaw;
        if (policyNumber == null || policyNumber.isBlank()) {
            log.warn("[CoreStubService] Request missing policy number → UNKNOWN response");
            responseRaw = FixedLengthMapper.buildUnknownResponse();
        } else {
            try {
                Optional<Policy> maybe = policyRepository.findByPolicyNumber(policyNumber);
                if (maybe.isPresent()) {
                    Policy p = maybe.get();
                    responseRaw = FixedLengthMapper.buildFixedResponse(p);
                    log.info("[CoreStubService] Policy {} FOUND → sending FIXED LENGTH response", policyNumber);
                } else {
                    responseRaw = FixedLengthMapper.buildNotFoundResponse(policyNumber);
                    log.info("[CoreStubService] Policy {} NOT FOUND → returning NOT_FOUND response", policyNumber);
                }
            } catch (Exception dbEx) {
                log.error("[CoreStubService] DB lookup error", dbEx);
                responseRaw = FixedLengthMapper.buildUnknownResponse();
            }
        }

        // STEP 5 — send policy response to MQ (single message)
        try {
            String targetQueue = (responseQueue == null || responseQueue.isBlank()) ? configuredResponseQueue : responseQueue;
            // log the policy response payload (padded) even if MQ is down
            log.info("[CoreStubService] Prepared policy response (to {}) -> {}", targetQueue, responseRaw);
            safeSendWithRetries(targetQueue, responseRaw, "policy=" + policyNumber, 3);
            log.info("[CoreStubService] Sent policy response to MQ queue {} → {}", targetQueue, responseRaw);
        } catch (Exception sendEx) {
            log.error("[CoreStubService] Could not send policy response to MQ", sendEx);
        }

        // STEP 6 — audit log
        try {
            AuditLog entry = new AuditLog();
            entry.setRequestRaw(requestJson);
            entry.setResponseRaw(responseRaw);
            auditLogRepository.save(entry);
        } catch (Exception e) {
            log.error("[CoreStubService] Failed to save audit log", e);
        }
    }

    /**
     * Public endpoint to trigger publishing of all claims as fixed-length messages to the response queue.
     */
    public void publishAllClaimsAsFixedToResponseQueue() {
        publishAllClaimsAsFixedToResponseQueueInternal(null);
    }

    // internal implementation with queue override
    private void publishAllClaimsAsFixedToResponseQueueInternal(String overrideQueue) {
        List<Claim> all;
        try {
            all = claimRepository.findAll();
        } catch (Exception e) {
            log.error("[CoreStubService] Could not read claims from Mongo", e);
            return;
        }
        if (all == null || all.isEmpty()) {
            log.info("[CoreStubService] No claims found to publish");
            return;
        }

        String targetQueue = (overrideQueue == null || overrideQueue.isBlank()) ? configuredResponseQueue : overrideQueue;
        log.info("[CoreStubService] publishAllClaimsAsFixedToResponseQueue -> publishing {} claims to {}",
                all.size(), targetQueue);

        int published = 0;
        for (Claim c : all) {
            try {
                String fixed = FixedLengthMapper.buildFixedClaimMessage(c);
                // log padded message so you can inspect even when MQ is down
                log.info("[CoreStubService] Prepared fixed message for claimId={} -> {} (len={})", c.getClaimId(), fixed, fixed.length());

                safeSendWithRetries(targetQueue, fixed, "claimId=" + c.getClaimId(), 4);
                published++;
            } catch (Exception ex) {
                log.error("[CoreStubService] Failed building/sending for claimId=" + c.getClaimId(), ex);
            }
        }

        log.info("[CoreStubService] publishAllClaimsAsFixedToResponseQueue -> finished publishing {} claims to {}",
                published, targetQueue);
    }

    /**
     * Publish claims that exactly match provided policyNumber (useful during the input/payload cycle).
     * Uses repository.findAll() and filters in-memory so this compiles against your current ClaimRepository.
     */
    private void publishClaimsByPolicyToResponseQueueInternal(String policyNumber, String overrideQueue) {
        if (policyNumber == null || policyNumber.isBlank()) {
            log.debug("[CoreStubService] publishClaimsByPolicyToResponseQueueInternal -> empty policyNumber, skip");
            return;
        }

        List<Claim> matches;
        try {
            List<Claim> all = claimRepository.findAll();
            matches = all.stream()
                    .filter(c -> policyNumber.equals(c.getPolicyNumber()))
                    .collect(Collectors.toList());
        } catch (Exception e) {
            log.error("[CoreStubService] Could not read claims from Mongo for policy {}", policyNumber, e);
            return;
        }

        if (matches == null || matches.isEmpty()) {
            log.info("[CoreStubService] No claims found for policy {} to publish", policyNumber);
            return;
        }

        String targetQueue = (overrideQueue == null || overrideQueue.isBlank()) ? configuredResponseQueue : overrideQueue;
        log.info("[CoreStubService] publishClaimsByPolicy -> publishing {} claims for policy {} to {}",
                matches.size(), policyNumber, targetQueue);

        int sent = 0;
        for (Claim c : matches) {
            try {
                String fixed = FixedLengthMapper.buildFixedClaimMessage(c);
                log.info("[CoreStubService] Prepared per-policy fixed message for claimId={} -> {} (len={})", c.getClaimId(), fixed, fixed.length());
                safeSendWithRetries(targetQueue, fixed, "claimId=" + c.getClaimId() + ",policy=" + policyNumber, 4);
                sent++;
            } catch (Exception ex) {
                log.error("[CoreStubService] Failed building/sending per-policy for claimId=" + c.getClaimId(), ex);
            }
        }
        log.info("[CoreStubService] publishClaimsByPolicy -> finished publishing {} claims for policy {} to {}",
                sent, policyNumber, targetQueue);
    }

    // helper: safe send with retries and small exponential backoff
    private void safeSendWithRetries(String queue, String payload, String context, int maxRetries) {
        int attempt = 0;
        long backoff = 300L;
        // Log the payload prior to attempting send so you can verify formatting even if MQ is down.
        log.debug("[CoreStubService] safeSendWithRetries: target={}, context={}, payloadLen={}, payload='{}'",
                queue, context, payload == null ? 0 : payload.length(), payload);

        while (attempt <= maxRetries) {
            try {
                jmsTemplate.convertAndSend(queue, payload);
                log.debug("[CoreStubService] Sent to {} -> {} (attempt={})", queue, context, attempt + 1);
                return;
            } catch (Exception ex) {
                attempt++;
                if (attempt > maxRetries) {
                    log.error("[CoreStubService] Giving up sending to {} for {} after {} attempts: {}",
                            queue, context, maxRetries, ex.toString());
                    return;
                } else {
                    log.warn("[CoreStubService] send to {} failed ({}). retrying in {}ms (attempt {}/{})",
                            queue, ex.getMessage(), backoff, attempt, maxRetries);
                    try { Thread.sleep(backoff); } catch (InterruptedException ignored) {}
                    backoff = Math.min(backoff * 2, 5000L);
                }
            }
        }
    }

    // --- helpers ---
    private static String sha256Hex(String input) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] digest = md.digest((input == null ? "" : input).getBytes(StandardCharsets.UTF_8));
            StringBuilder sb = new StringBuilder(digest.length * 2);
            for (byte b : digest) sb.append(String.format("%02x", b));
            return sb.toString();
        } catch (Exception e) {
            return "hff-" + UUID.randomUUID().toString();
        }
    }
}
