package com.intelliclaim.corestub.config;

import com.ibm.mq.jakarta.jms.MQQueueConnectionFactory;
import com.ibm.msg.client.jakarta.wmq.WMQConstants;
import jakarta.jms.ConnectionFactory;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jms.config.DefaultJmsListenerContainerFactory;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.jms.connection.CachingConnectionFactory;
import org.springframework.jms.connection.UserCredentialsConnectionFactoryAdapter;

import java.util.Map;

@Configuration
public class JmsConfig {

    private final IbmmqProperties props;


    private Map<String, MQQueueConnectionFactory> connectionFactories = null;
    public JmsConfig(IbmmqProperties props) {
        this.props = props;
    }

    /**
     * Create and configure the IBM MQ connection factory.
     */
    @Bean
    public ConnectionFactory mqConnectionFactory() throws Exception {
        MQQueueConnectionFactory cf = new MQQueueConnectionFactory();
        // client mode
        cf.setTransportType(WMQConstants.WMQ_CM_CLIENT);
        cf.setHostName(props.getHost());
        cf.setPort(props.getPort());
        cf.setChannel(props.getChannel());
        cf.setQueueManager(props.getQueueManager());

        // MQQueueConnectionFactory implements jakarta.jms.ConnectionFactory
        return (ConnectionFactory) cf;
    }

    /**
     * Wrap the raw connection factory with credentials (optional) and caching.
     */
    @Bean
    public ConnectionFactory jmsConnectionFactory() throws Exception {
        ConnectionFactory target = mqConnectionFactory();


        // apply credentials only if user is provided
        if (props.getUser() != null && !props.getUser().isBlank()) {
            UserCredentialsConnectionFactoryAdapter adapter = new UserCredentialsConnectionFactoryAdapter();
            adapter.setTargetConnectionFactory(target);
            adapter.setUsername(props.getUser());
            adapter.setPassword(props.getPassword());
            target = adapter;
        }

        CachingConnectionFactory caching = new CachingConnectionFactory(target);
        caching.setSessionCacheSize(10);
        return caching;
    }

    @Bean("jmsListenerContainerFactory")
    public DefaultJmsListenerContainerFactory jmsListenerContainerFactory(ConnectionFactory jmsConnectionFactory) {
        DefaultJmsListenerContainerFactory factory = new DefaultJmsListenerContainerFactory();
        factory.setConnectionFactory(jmsConnectionFactory);
        factory.setConcurrency("1-3");
        factory.setPubSubDomain(false);
        factory.setSessionTransacted(false);
        return factory;
    }

    @Bean
    public JmsTemplate jmsTemplate(ConnectionFactory jmsConnectionFactory) {
        JmsTemplate t = new JmsTemplate(jmsConnectionFactory);
        t.setDeliveryPersistent(true);
        t.setSessionTransacted(false);
        return t;
    }
}
