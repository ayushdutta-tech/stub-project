package com.intelliclaim.corestub.controller;

import com.intelliclaim.corestub.service.CoreStubService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/claims")
public class ClaimController {

    private final CoreStubService coreStubService;

    public ClaimController(CoreStubService coreStubService) {
        this.coreStubService = coreStubService;
    }

    @PostMapping("/publish-fixed")
    public ResponseEntity<String> publishAllAsFixed() {
        coreStubService.publishAllClaimsAsFixedToResponseQueue();
        return ResponseEntity.ok("Triggered publish of all claims as fixed-length to response queue");
    }
}
