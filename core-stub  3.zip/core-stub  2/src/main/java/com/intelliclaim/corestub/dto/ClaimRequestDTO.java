package com.intelliclaim.corestub.dto;

public class ClaimRequestDTO {
    private String policyNumber;
    private String claimantName;
    private Double claimAmount;

    public ClaimRequestDTO() {}

    public ClaimRequestDTO(String policyNumber, String claimantName, Double claimAmount) {
        this.policyNumber = policyNumber;
        this.claimantName = claimantName;
        this.claimAmount = claimAmount;
    }

    public String getPolicyNumber() { return policyNumber; }
    public void setPolicyNumber(String policyNumber) { this.policyNumber = policyNumber; }

    public String getClaimantName() { return claimantName; }
    public void setClaimantName(String claimantName) { this.claimantName = claimantName; }

    public Double getClaimAmount() { return claimAmount; }
    public void setClaimAmount(Double claimAmount) { this.claimAmount = claimAmount; }
}
