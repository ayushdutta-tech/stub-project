package com.intelliclaim.corestub.mq;

import com.intelliclaim.corestub.dto.ClaimRequestDTO;
import com.intelliclaim.corestub.model.Claim;
import com.intelliclaim.corestub.model.Policy;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.stream.Collectors;

/**
 * FixedLengthMapper
 *
 * Parser for incoming fixed-length requests and builders for various fixed-length responses.
 * Defensive substring handling and numeric parsing.
 */
public class FixedLengthMapper {

    // Incoming request fixed-length spec
    private static final int MSG_TYPE_LEN = 10;
    private static final int POLICY_NUM_LEN = 20;
    private static final int HOLDER_NAME_LEN = 40;
    private static final int AMOUNT_LEN = 10;

    private static final int OFFSET_MSG_TYPE = 0;
    private static final int OFFSET_POLICY_NUM = OFFSET_MSG_TYPE + MSG_TYPE_LEN; // 10
    private static final int OFFSET_HOLDER_NAME = OFFSET_POLICY_NUM + POLICY_NUM_LEN; // 30
    private static final int OFFSET_AMOUNT = OFFSET_HOLDER_NAME + HOLDER_NAME_LEN; // 70

    // ---------------- Claim response fixed-length fields (target spec: total = 110) ----------------
    private static final int CLAIM_ID_LEN = 36;             // pos 1
    private static final int CLAIM_POLICY_NUM_LEN = 12;     // pos 2
    private static final int CLAIM_HOLDER_NAME_LEN = 12;    // pos 3
    private static final int CLAIM_AMOUNT_LEN = 10;         // pos 4 (right aligned)
    private static final int CLAIM_FRAUD_STATUS_LEN = 10;   // pos 5
    private static final int CLAIM_STATUS_LEN = 8;          // pos 6
    private static final int CLAIM_CREATED_DATE_LEN = 16;   // pos 7 (yyyyMMddHHmmss padded)
    private static final int CLAIM_PADDING_LEN = 6;         // pos 8 (6 spaces)

    private static final DateTimeFormatter CREATED_DATE_FMT = DateTimeFormatter.ofPattern("yyyyMMddHHmmss");

    // ---------------- Parser: fixed-length -> ClaimRequestDTO ----------------
    public static ClaimRequestDTO parseFixedToClaimRequest(String raw) {
        ClaimRequestDTO dto = new ClaimRequestDTO();
        if (raw == null) return dto;

        String r = raw;

        // policyNumber
        String policyNumber = "";
        if (r.length() >= OFFSET_POLICY_NUM + 1) {
            int end = Math.min(r.length(), OFFSET_POLICY_NUM + POLICY_NUM_LEN);
            policyNumber = safeSubstring(r, OFFSET_POLICY_NUM, end).trim();
        }

        // claimantName
        String claimantName = "";
        if (r.length() >= OFFSET_HOLDER_NAME + 1) {
            int end = Math.min(r.length(), OFFSET_HOLDER_NAME + HOLDER_NAME_LEN);
            claimantName = safeSubstring(r, OFFSET_HOLDER_NAME, end).trim();
        }

        // claimAmount (right aligned)
        Double claimAmount = null;
        if (r.length() >= OFFSET_AMOUNT + 1) {
            int end = Math.min(r.length(), OFFSET_AMOUNT + AMOUNT_LEN);
            String amtStr = safeSubstring(r, OFFSET_AMOUNT, end).trim();

            if (!amtStr.isEmpty()) {
                // remove any characters except digits, dot and minus sign (defensive)
                String cleaned = amtStr.replaceAll("[^0-9.\\-]", "");
                try {
                    claimAmount = Double.valueOf(cleaned);
                } catch (NumberFormatException e) {
                    // fallback: try replacing commas
                    try {
                        claimAmount = Double.valueOf(cleaned.replaceAll(",", ""));
                    } catch (Exception ex) {
                        claimAmount = null;
                    }
                }
            }
        }

        dto.setPolicyNumber(policyNumber);
        dto.setClaimantName(claimantName);
        dto.setClaimAmount(claimAmount);

        return dto;
    }

    // ---------------- Existing helpers / request builders (kept) ----------------

    public static String buildFixedRequest(String policyNumber) {
        return padRight("REQ", MSG_TYPE_LEN)
                + padRight(policyNumber == null ? "" : policyNumber, POLICY_NUM_LEN)
                + padRight("", HOLDER_NAME_LEN)
                + padLeft("0.00", AMOUNT_LEN);
    }

    public static String buildFixedResponse(Policy p) {
        StringBuilder sb = new StringBuilder();
        sb.append(padRight("RESP", MSG_TYPE_LEN));
        sb.append(padRight(nullSafe(p.getPolicyNumber()), POLICY_NUM_LEN));
        sb.append(padRight(nullSafe(p.getPolicyHolderName()), HOLDER_NAME_LEN));
        double amount = p.getSumInsured() == null ? 0.0 : p.getSumInsured();
        sb.append(padLeft(String.format("%.2f", amount), AMOUNT_LEN));
        return sb.toString();
    }

    public static String buildNotFoundResponse(String policyNumber) {
        StringBuilder sb = new StringBuilder();
        sb.append(padRight("RESP", MSG_TYPE_LEN));
        sb.append(padRight(policyNumber == null ? "" : policyNumber, POLICY_NUM_LEN));
        sb.append(padRight("NOT_FOUND", HOLDER_NAME_LEN));
        sb.append(padLeft("0.00", AMOUNT_LEN));
        return sb.toString();
    }

    public static String buildUnknownResponse() {
        StringBuilder sb = new StringBuilder();
        sb.append(padRight("RESP", MSG_TYPE_LEN));
        sb.append(padRight("UNKNOWN", POLICY_NUM_LEN));
        sb.append(padRight("", HOLDER_NAME_LEN));
        sb.append(padLeft("0.00", AMOUNT_LEN));
        return sb.toString();
    }

    // ---------------- NEW: claim -> fixed-length message builder (matches FixedLengthClaimRecord) ----------------

    /**
     * Build a fixed-length message representing a Claim to be sent on response queue.
     * Uses exactly the layout you specified:
     *   id(36) | policyNumber(12) | claimantName(12) | claimAmount(10 right aligned) |
     *   fraudStatus(10) | status(8) | createdDate(16 yyyyMMddHHmmss padded) | padding(6)
     * Total length = 110 characters.
     */
    public static String buildFixedClaimMessage(Claim c) {
        StringBuilder sb = new StringBuilder();

        // id (36) — left aligned
        sb.append(padRight(truncateTo(nullSafe(c.getClaimId()), CLAIM_ID_LEN), CLAIM_ID_LEN));

        // policy number (12) — left aligned, truncated if needed
        sb.append(padRight(truncateTo(nullSafe(c.getPolicyNumber()), CLAIM_POLICY_NUM_LEN), CLAIM_POLICY_NUM_LEN));

        // claimant name (12) — left aligned
        sb.append(padRight(truncateTo(nullSafe(c.getClaimantName()), CLAIM_HOLDER_NAME_LEN), CLAIM_HOLDER_NAME_LEN));

        // claim amount (10) — right aligned with 2 decimals
        double amountVal = c.getClaimAmount() == null ? 0.0 : c.getClaimAmount();
        String amountStr = String.format("%.2f", amountVal);
        sb.append(padLeft(amountStr, CLAIM_AMOUNT_LEN));

        // fraud status (10) — left aligned
        String fraudStatus = "";
        try {
            Object fs = c.getClass().getMethod("getFraudStatus").invoke(c);
            fraudStatus = (fs == null) ? "" : fs.toString();
        } catch (Exception ignored) {
            fraudStatus = "";
        }
        sb.append(padRight(truncateTo(fraudStatus, CLAIM_FRAUD_STATUS_LEN), CLAIM_FRAUD_STATUS_LEN));

        // status (8) — left aligned
        sb.append(padRight(truncateTo(nullSafe(c.getStatus()), CLAIM_STATUS_LEN), CLAIM_STATUS_LEN));

        // createdDate (16) — yyyyMMddHHmmss (14) then pad right to 16
        String createdDateStr = "";
        try {
            LocalDateTime dt = c.getCreatedDate();
            if (dt == null) dt = LocalDateTime.now();
            createdDateStr = dt.format(CREATED_DATE_FMT);
        } catch (Exception ignored) {
            createdDateStr = "";
        }
        sb.append(padRight(truncateTo(createdDateStr, CLAIM_CREATED_DATE_LEN), CLAIM_CREATED_DATE_LEN));

        // trailing padding 6 spaces
        sb.append(padRight("", CLAIM_PADDING_LEN));

        // final safety: ensure exact 110 chars
        String out = sb.toString();
        if (out.length() > 110) {
            return out.substring(0, 110);
        } else if (out.length() < 110) {
            return padRight(out, 110);
        } else {
            return out;
        }
    }

    public static List<String> buildFixedClaimMessages(List<Claim> claims) {
        return claims.stream().map(FixedLengthMapper::buildFixedClaimMessage).collect(Collectors.toList());
    }

    // ---------------- Utility helpers ----------------

    private static String safeSubstring(String s, int startInclusive, int endExclusive) {
        if (s == null || startInclusive >= s.length()) return "";
        int safeEnd = Math.min(endExclusive, s.length());
        if (startInclusive < 0) startInclusive = 0;
        if (safeEnd <= startInclusive) return "";
        return s.substring(startInclusive, safeEnd);
    }

    public static String padRight(String s, int size) {
        if (s == null) s = "";
        if (s.length() > size) return s.substring(0, size);
        return String.format("%-" + size + "s", s);
    }

    public static String padLeft(String s, int size) {
        if (s == null) s = "";
        if (s.length() > size) return s.substring(0, size);
        return String.format("%" + size + "s", s);
    }

    private static String nullSafe(String s) { return s == null ? "" : s; }

    private static String truncateTo(String s, int size) {
        if (s == null) return "";
        if (s.length() <= size) return s;
        return s.substring(0, size);
    }
}
