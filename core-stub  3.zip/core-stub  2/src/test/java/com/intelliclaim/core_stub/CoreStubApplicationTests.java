package com.intelliclaim.core_stub;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CoreStubApplicationTests {

	@Test
	void contextLoads() {
	}

}
